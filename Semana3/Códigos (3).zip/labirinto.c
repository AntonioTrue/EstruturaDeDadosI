#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h> // sleep, usleep

// Variável de controle global (Sinalizador / Flag): 
// Funciona como um mecanismo de interrupção global. Quando vira 'true',
// faz com que todas as chamadas recursivas pendentes na pilha retornem imediatamente.
bool achouSaida = false;
char **mapa;
int nl, nc;

char **alocaMatriz(int linhas, int colunas){
    char **matriz = malloc(linhas * sizeof(char *));
    for (int i = 0; i < linhas; i++){
        matriz[i] = malloc(colunas * sizeof(char));
    }
    return matriz;
}

void imprime(char **matriz, int linhas, int colunas){
    for(int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++)
            printf("%c", matriz[i][j]);
        printf("\n");
    }
}

void liberaMatriz(char **matriz, int linhas, int colunas) {
    for (int i = 0; i < linhas; i++)
        free(matriz[i]);
    free(matriz);
}

// Redesenha o mapa no terminal com uma mensagem e uma pequena pausa
void desenhaEPausa(const char *mensagem, int l, int c) {
    // O "clear" funciona em Linux/macOS/WSL. 
    // Em ambiente Windows nativo (CMD/PowerShell), altere para system("cls").
    system("clear");
    printf("%s (%d, %d)\n\n", mensagem, l, c);
    imprime(mapa, nl, nc);

    // Se o mapa for muito grande, reduza este valor (ex: 30000) para acelerar a animação.
    usleep(150000); // Faz uma pausa de 150 milissegundos
}

/**
 * Função Auxiliar: posicaoValida
 * -----------------------------
 * Determina se a coordenada (l, c) é uma célula válida para onde o algoritmo pode avançar.
 * 
 * Uma posição é considerada válida se satisfizer DUAS condições:
 *   1. Estar dentro dos limites válidos da matriz (0 <= l < nl e 0 <= c < nc).
 *   2. Não ser um obstáculo/parede ('#') e não ter sido visitada no caminho atual ('v').
 * 
 * @param l Índice da linha.
 * @param c Índice da coluna.
 * @return true se a posição for válida para avanço; false caso contrário.
 */
bool posicaoValida(int l, int c) {
    // 1. Validação de limites da matriz
    if (l < 0 || c < 0 || l >= nl || c >= nc)
        return false;
    // 2. Validação do conteúdo da célula
    return mapa[l][c] != '#' && mapa[l][c] != 'v';
}

/**
 * Função Principal de Busca: caminha
 * ----------------------------------
 * Executa uma busca recursiva em profundidade (DFS) com Backtracking para
 * encontrar um caminho válido a partir da posição (l, c) até a saída ('E').
 * 
 * Lógica de Funcionamento:
 *   1. Poda de Sucesso: Interrompe a busca se a saída já foi encontrada em outro ramo.
 *   2. Inviabilidade: Retorna se a posição (l, c) for inválida, parede ou já visitada.
 *   3. Caso Base: Se a célula atual for 'E', registra o sucesso e encerra o algoritmo.
 *   4. Avanço (Passo Recursivo): Marca a posição atual como visitada ('v') e dispara
 *      chamadas recursivas para as 4 direções vizinhas (Esquerda, Direita, Cima, Baixo).
 *   5. Backtracking: Se nenhuma das 4 direções levar à saída, desmarca a célula
 *      (restaurando para '.') para liberar a posição para outros caminhos na árvore de busca.
 * 
 * @param l Índice da linha atual na matriz do mapa.
 * @param c Índice da coluna atual na matriz do mapa.
 */
void caminha(int l, int c) {
    // 1. PODA DE SUCESSO: Se a saída já foi encontrada por outro ramo da árvore,
    // interrompe imediatamente todas as chamadas ativas na pilha de recursão.
    if (achouSaida)
        return;

    // 2. CONDIÇÃO DE INVIABILIDADE: Verifica se a célula atual pode ser acessada.
    // Retorna se for fora do mapa, parede ('#') ou se já foi visitada no caminho atual ('v').
    if (!posicaoValida(l, c))
        return;

    // 3. CASO BASE (SUCESSO): Se a célula atual for a saída ('E'), registra o sucesso,
    // desenha a matriz final e inicia o encerramento da busca.
    if (mapa[l][c] == 'E') {
        achouSaida = true;
        desenhaEPausa("Saida encontrada em", l, c);
        return;
    }

    // 4. AVANÇO (Mudança de Estado): Marca temporariamente a célula como parte
    // do caminho sendo testado no momento para evitar ciclos/loops infinitos.
    mapa[l][c] = 'v';
    desenhaEPausa("Visitando", l, c);

    // 5. EXPLORAÇÃO (RAMIFICAÇÃO): Testa recursivamente as 4 direções vizinhas.
    // A ordem destas chamadas define a prioridade de exploração no mapa.
    caminha(l, c - 1); // Tenta avançar para a Esquerda
    caminha(l, c + 1); // Tenta avançar para a Direita
    caminha(l - 1, c); // Tenta avançar para Cima
    caminha(l + 1, c); // Tenta avançar para Baixo

    // 6. BACKTRACKING (Desfazimento de Escolha / Retorno de Estado):
    // Se nenhuma das 4 direções acima levou à saída, significa que esta célula 
    // caiu em um beco sem saída. Restauramos a célula para '.' para que ela possa 
    // ser explorada por outros caminhos alternativos que venham de outros nós.
    if (!achouSaida) {
        mapa[l][c] = '.';
        desenhaEPausa("Recuando (Backtracking) de", l, c);
    }
}

// Varre o mapa procurando o caractere alvo (usada para achar 'S')
void acha(char alvo, int *l, int *c) {
    for (int i = 0; i < nl; i++)
        for (int j = 0; j < nc; j++)
            if (mapa[i][j] == alvo) {
                *l = i;
                *c = j;
                return;
            }
}

int main() {
    scanf("%d %d", &nl, &nc);
    // Note o tamanho 'nc + 1': em C, strings lidas via %s precisam de 1 byte extra 
    // para o caractere terminador de string ('\0').
    mapa = alocaMatriz(nl, nc + 1);
    for (int i = 0; i < nl; i++)
        scanf("%s", mapa[i]);

    int li, ci;
    acha('S', &li, &ci);

    caminha(li, ci);

    if (achouSaida)
        printf("Saida encontrada!\n");
    else
        printf("Solucao nao encontrada\n");

    liberaMatriz(mapa, nl, nc);
    return 0;
}