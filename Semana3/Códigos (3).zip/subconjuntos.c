#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int n;
long long limite;
int *valores;
bool *pertence;

// Contador para mensurar a quantidade de nós visitados na árvore de recursão
long long chamadas = 0;

void imprime() {
    printf("{ ");
    for (int i = 0; i < n; i++)
        if (pertence[i])
            printf("%d ", valores[i]);
    printf("}\n");
}

void geraSubconjuntos(int i, long long soma) {
    chamadas++; // Incrementa a cada nó visitado

    if (soma > limite)
        return;

    if (i == n) {
        imprime();
        return;
    }

    pertence[i] = false;
    geraSubconjuntos(i + 1, soma);
    
    pertence[i] = true;
    geraSubconjuntos(i + 1, soma + valores[i]);
}

int main() {
    if (scanf("%d %lld", &n, &limite) != 2) return 1;

    valores = malloc(n * sizeof(int));
    pertence = malloc(n * sizeof(bool));
    for (int i = 0; i < n; i++)
        scanf("%d", &valores[i]);

    geraSubconjuntos(0, 0);

    printf("\n--- METRICAS ---\n");
    printf("Total de chamadas recursivas: %lld\n", chamadas);

    free(valores);
    free(pertence);
    return 0;
}