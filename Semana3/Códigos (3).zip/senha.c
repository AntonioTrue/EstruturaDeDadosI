#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

// Alfabeto permitido
const char LETRAS[] = "abcdefghijklmnopqrstuvwxyz";
const int NUM_LETRAS = 26;

// Flag global para indicar se a senha já foi encontrada e parar a busca
bool encontrada = false;

/**
 * Função de hash DJB2
 * Converte uma string qualquer em um valor unsigned long de 32/64 bits.
 */
unsigned long djb2_hash(const char *str) {
    unsigned long hash = 5381;
    int c;

    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c;
    }

    return hash;
}

/**
 * Função recursiva de Força Bruta para testar senhas.
 * 
 * @param i          Comprimento atual da senha sendo montada.
 * @param n          Limite superior para o comprimento (senhas de tamanho < n).
 * @param senha      Vetor que armazena a string da senha atual.
 * @param hash_alvo  O valor do hash que queremos encontrar.
 */
void quebraSenha(int i, int n, char *senha, unsigned long hash_alvo) {
    // 1. Condição de parada por sucesso
    // Se a variável global 'encontrada' for verdadeira (1), retorne imediatamente.

    // 2. Caso base de profundidade
    // Se 'i' for maior que 'n', ultrapassamos o tamanho máximo permitido. Retorne.

    // 3. Teste da senha atual
    // Se i > 0, temos uma senha válida de tamanho 'i' montada no vetor:
    //  a) Adicione o caractere nulo '\0' na posição 'i' do vetor para finalizar a string.
    //  b) Calcule o hash da string usando a função 'djb2_hash'.
    //  c) Se o hash for igual a 'hash_alvo':
    //     - Imprima a mensagem de sucesso e a senha encontrada.
    //     - Marque 'encontrada = true'.
    //     - Retorne.
    if (i > 0) {
        senha[i] = '\0';
        // Com você :)
    }

    // 4. Passo recursivo (Ramificação)
    // Percorra todas as 26 escolhas possíveis de caracteres (de 'a' até 'z'):
    //  a) Atribua o caractere atual à posição 'i' do vetor 'senha'.
    //  b) Faça a chamada recursiva para a próxima posição (i + 1).
}

int main() {
    // Define o limite n (testará senhas de tamanho 1 até n)
    int n = 4;

    // Aloca n + 1 para caber n caracteres + '\0'
    char *senha = (char *)malloc((n + 1) * sizeof(char));
    if (senha == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        return 1;
    }

    unsigned long hash_alvo = 6385760056UL;

    printf("Iniciando busca por força bruta para o hash: %lu\n", hash_alvo);
    printf("Procurando senhas com comprimento menor que %d...\n", n);

    // Medição do tempo de CPU
    clock_t inicio = clock();

    quebraSenha(0, n, senha, hash_alvo);

    double tempoGasto = (double)(clock() - inicio) / CLOCKS_PER_SEC;

    if (!encontrada) {
        printf("\n[FALHA] Nenhuma senha com comprimento < %d corresponde ao hash fornecido.\n", n);
    }

    printf("Tempo total gasto: %.4f segundos\n", tempoGasto);

    free(senha);
    return 0;
}