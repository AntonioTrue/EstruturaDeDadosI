// Preenchimento de Regiões Contíguas (Flood Fill / DFS)
//
// Dado um mapa com '.' (água) e '#' (terra), o algoritmo encontra
// e marca todas as componentes conectadas (ilhas/regiões).
//
// Diferenças para o Labirinto:
//  - Não há ponto de saída nem busca de menor caminho.
//  - Percorre recursivamente toda a região de '#' contígua.
//  - NUNCA desmarca uma célula (não há desfazimento/backtracking).
/*
Exemplo:
Tamanho do mapa: 7 8
..#...#.
..#####.
#...#...
##......
###...#.
.....###
..#...#.
Número de regiões: 4
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int qtRegioes = 0;
char **mapa;
int nl, nc;

char **alocaMatriz(int linhas, int colunas){
    char **matriz = malloc(linhas * sizeof(char *)); 
    for (int i = 0; i < linhas; i++){
        matriz[i] = malloc(colunas * sizeof(char)); 
    }
    return matriz;
}

void imprime(char **matriz, int linhas, int colunas){
    for(int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++)
            printf("%c", matriz[i][j]);
        printf("\n");
    }
}

void liberaMatriz(char **matriz, int linhas) {
    for (int i = 0; i < linhas; i++)
        free(matriz[i]);
    free(matriz);
}

/**
 * Função Auxiliar de Preenchimento: caminha (Flood Fill / DFS)
 * -----------------------------------------------------------
 * Percorre recursivamente todas as células de terra ('#') contíguas
 * a partir da coordenada (l, c), marcando toda a componente conectada (ilha).
 *
 * Lógica de Funcionamento:
 *   1. Caso Base / Inviabilidade: Retorna se a coordenada estiver fora dos limites
 *      da matriz ou se a célula não for terra ('#') (ex: água '.' ou já visitada 'o').
 *   2. Mudança de Estado: Marca a célula atual como 'o' para registrá-la como
 *      pertencente à região atual e evitar reprocessamento ou loops infinitos.
 *   3. Propagação Recursiva: Dispara a exploração para as 4 direções vizinhas
 *      (Esquerda, Direita, Cima, Baixo) para "queimar"/mapear toda a ilha.
 *
 * NOTA: Esta função NÃO utiliza Backtracking (não há desfazimento de jogadas), pois
 * qualquer célula de terra visitada pertence definitivamente à região encontrada.
 *
 * @param l Índice da linha atual no mapa.
 * @param c Índice da coluna atual no mapa.
 */
void caminha(int l, int c) {
    / TODO 1 : CASO BASE(Limites)
    // Verifica se a coordenada (l, c) está fora da matriz (l < 0, c < 0, l >= nl, c >= nc).
    // Se estiver fora, encerra a chamada com 'return;'.

    // TODO 2: CASO BASE (Inviabilidade)
    // Verifica se a posição atual NÃO é terra ('#').
    // Se for água ('.') ou já tiver sido visitada ('o'), interrompe a busca nesta direção com 'return;'.

    // TODO 3: MUDANÇA DE ESTADO (Consumo da Célula)
    // Marca a posição atual como visitada (ex: mapa[l][c] = 'o';).
    // Isso "queima" a célula para que ela não seja contada novamente no loop da main().

    // TODO 4: PASSO RECURSIVO (Propagação)
    // Chama recursivamente caminha() para os 4 vizinhos (Esquerda, Direita, Cima, Baixo).
    // Exemplo: caminha(l, c - 1); // Esquerda
}

int main() {
    scanf("%d %d", &nl, &nc);
    mapa = alocaMatriz(nl, nc + 1);
    for(int i = 0; i < nl; i++) {
        scanf("%s", mapa[i]);
    }

    for(int i = 0; i < nl; i++) {         //Procura região ainda não vista
        for(int j = 0; j < nc; j++) 
            if (mapa[i][j] == '#') {    //Se achou uma região ainda não vista
                qtRegioes++;
                printf("Encontrada regiao %d\n", qtRegioes);
                caminha(i, j);     //Visita a região toda, por backtracking
                printf("Regiao %d marcada\n", qtRegioes);
                imprime(mapa, nl, nc);
                printf("\n");
            }
        }


    printf("Total de regiões: %d\n", qtRegioes);
    return 0;
}
